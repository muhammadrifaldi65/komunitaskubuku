"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";

interface CommentAuthor {
  id: string;
  username: string;
  name: string;
  avatarUrl?: string | null;
  role: string;
}
interface CommentData {
  id: string;
  content: string;
  createdAt: string;
  author: CommentAuthor;
  replies?: CommentData[];
}

function timeAgo(dateStr: string) {
  const diff = (Date.now() - new Date(dateStr).getTime()) / 1000;
  if (diff < 60) return "baru saja";
  if (diff < 3600) return `${Math.floor(diff / 60)}m`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}j`;
  return `${Math.floor(diff / 86400)}h`;
}

function CommentItem({ comment, postId, onReplied }: { comment: CommentData; postId: string; onReplied: () => void }) {
  const { data: session } = useSession();
  const [replying, setReplying] = useState(false);
  const [replyText, setReplyText] = useState("");
  const [busy, setBusy] = useState(false);

  async function submitReply() {
    if (!session) return (window.location.href = "/login");
    if (!replyText.trim()) return;
    setBusy(true);
    const res = await fetch(`/api/posts/${postId}/comments`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: replyText, parentId: comment.id }),
    });
    setBusy(false);
    if (res.ok) {
      setReplyText("");
      setReplying(false);
      onReplied();
    }
  }

  return (
    <div className="py-2">
      <div className="flex gap-2">
        <img
          src={comment.author.avatarUrl || `https://api.dicebear.com/7.x/initials/svg?seed=${comment.author.name}`}
          className="w-7 h-7 rounded-full object-cover border"
          alt=""
        />
        <div className="flex-1">
          <div className="bg-gray-100 rounded-xl px-3 py-2">
            <Link href={`/profile/${comment.author.username}`} className="font-semibold text-xs hover:underline">
              {comment.author.name}
            </Link>
            <p className="text-sm">{comment.content}</p>
          </div>
          <div className="flex items-center gap-3 text-xs text-gray-400 mt-1 px-1">
            <span>{timeAgo(comment.createdAt)}</span>
            <button onClick={() => setReplying((r) => !r)} className="hover:underline">
              Balas
            </button>
          </div>

          {replying && (
            <div className="mt-1 flex gap-1">
              <input
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="Tulis balasan..."
                className="flex-1 border rounded-full px-3 py-1 text-xs"
              />
              <button disabled={busy} onClick={submitReply} className="text-xs text-emerald-700 font-medium px-2">
                Kirim
              </button>
            </div>
          )}

          {comment.replies && comment.replies.length > 0 && (
            <div className="ml-4 mt-1 border-l pl-3">
              {comment.replies.map((r) => (
                <CommentItem key={r.id} comment={r} postId={postId} onReplied={onReplied} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function CommentSection({ postId }: { postId: string }) {
  const { data: session } = useSession();
  const [comments, setComments] = useState<CommentData[]>([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  async function load() {
    setLoading(true);
    const res = await fetch(`/api/posts/${postId}/comments`);
    const data = await res.json();
    if (res.ok) setComments(data.comments);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [postId]);

  async function submitComment(e: React.FormEvent) {
    e.preventDefault();
    if (!session) return (window.location.href = "/login");
    if (!text.trim()) return;
    setBusy(true);
    const res = await fetch(`/api/posts/${postId}/comments`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: text }),
    });
    setBusy(false);
    if (res.ok) {
      setText("");
      load();
    }
  }

  return (
    <div className="mt-3">
      <form onSubmit={submitComment} className="flex gap-2 mb-3">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={session ? "Tulis komentar..." : "Masuk untuk berkomentar"}
          disabled={!session}
          className="flex-1 border rounded-full px-3 py-1.5 text-sm"
        />
        <button disabled={busy} className="text-sm text-emerald-700 font-medium px-2">
          Kirim
        </button>
      </form>

      {loading && <p className="text-xs text-gray-400">Memuat komentar...</p>}
      {!loading && comments.length === 0 && <p className="text-xs text-gray-400">Belum ada komentar.</p>}
      {comments.map((c) => (
        <CommentItem key={c.id} comment={c} postId={postId} onReplied={load} />
      ))}
    </div>
  );
}
