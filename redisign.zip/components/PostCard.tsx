"use client";

import Link from "next/link";
import { useState } from "react";
import { useSession } from "next-auth/react";

export interface PostAuthor {
  id: string;
  username: string;
  name: string;
  avatarUrl?: string | null;
  role: "ADMIN" | "PEMBINA" | "USER";
}

export interface PostData {
  id: string;
  content: string;
  imageUrl?: string | null;
  bookTitle?: string | null;
  bookAuthor?: string | null;
  createdAt: string;
  likeCount: number;
  dislikeCount: number;
  commentCount: number;
  shareCount: number;
  author: PostAuthor;
  myReaction?: "LIKE" | "DISLIKE" | null;
  isBookmarked?: boolean;
}

function timeAgo(dateStr: string) {
  const diff = (Date.now() - new Date(dateStr).getTime()) / 1000;
  if (diff < 60) return "baru saja";
  if (diff < 3600) return `${Math.floor(diff / 60)}m`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}j`;
  return `${Math.floor(diff / 86400)}h`;
}

export default function PostCard({ post }: { post: PostData }) {
  const { data: session } = useSession();
  const [state, setState] = useState(post);
  const [busy, setBusy] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [reportReason, setReportReason] = useState("");

  async function react(type: "LIKE" | "DISLIKE") {
    if (!session) return (window.location.href = "/login");
    if (busy) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/posts/${state.id}/react`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type }),
      });
      const data = await res.json();
      if (res.ok) {
        setState((s) => ({ ...s, likeCount: data.likeCount, dislikeCount: data.dislikeCount, myReaction: data.myReaction }));
      }
    } finally {
      setBusy(false);
    }
  }

  async function toggleBookmark() {
    if (!session) return (window.location.href = "/login");
    const res = await fetch(`/api/posts/${state.id}/bookmark`, { method: "POST" });
    const data = await res.json();
    if (res.ok) setState((s) => ({ ...s, isBookmarked: data.bookmarked }));
  }

  async function share() {
    const res = await fetch(`/api/posts/${state.id}/share`, { method: "POST" });
    const data = await res.json();
    if (res.ok) setState((s) => ({ ...s, shareCount: data.shareCount }));
    const url = `${window.location.origin}/post/${state.id}`;
    if (navigator.share) {
      navigator.share({ url }).catch(() => {});
    } else {
      navigator.clipboard.writeText(url);
      alert("Tautan post disalin ke clipboard!");
    }
  }

  async function submitReport() {
    if (!session) return (window.location.href = "/login");
    if (!reportReason.trim()) return;
    const res = await fetch(`/api/posts/${state.id}/report`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reason: reportReason }),
    });
    if (res.ok) {
      alert("Laporan terkirim. Terima kasih!");
      setShowReport(false);
      setReportReason("");
    }
  }

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-4 mb-3">
      <div className="flex items-center justify-between">
        <Link href={`/profile/${state.author.username}`} className="flex items-center gap-2">
          <img
            src={state.author.avatarUrl || `https://api.dicebear.com/7.x/initials/svg?seed=${state.author.name}`}
            className="w-9 h-9 rounded-full object-cover border"
            alt=""
          />
          <div>
            <div className="flex items-center gap-1">
              <span className="font-semibold text-sm">{state.author.name}</span>
              {state.author.role !== "USER" && (
                <span className="text-[10px] px-1.5 py-0.5 bg-emerald-100 text-emerald-700 rounded-full">
                  {state.author.role === "ADMIN" ? "Admin" : "Pembina"}
                </span>
              )}
            </div>
            <div className="text-xs text-gray-400">
              @{state.author.username} · {timeAgo(state.createdAt)}
            </div>
          </div>
        </Link>
        <button onClick={() => setShowReport((s) => !s)} className="text-gray-400 hover:text-gray-600 text-sm px-2">
          ⋯
        </button>
      </div>

      {(state.bookTitle || state.bookAuthor) && (
        <div className="mt-2 text-xs inline-flex items-center gap-1 bg-amber-50 text-amber-800 px-2 py-1 rounded-md">
          📕 {state.bookTitle}
          {state.bookAuthor ? ` — ${state.bookAuthor}` : ""}
        </div>
      )}

      <Link href={`/post/${state.id}`}>
        <p className="mt-2 text-sm whitespace-pre-wrap">{state.content}</p>
        {state.imageUrl && (
          <img src={state.imageUrl} alt="" className="mt-2 rounded-lg max-h-[480px] w-full object-cover border" />
        )}
      </Link>

      {showReport && (
        <div className="mt-2 p-2 bg-gray-50 rounded-lg text-sm">
          <input
            value={reportReason}
            onChange={(e) => setReportReason(e.target.value)}
            placeholder="Alasan melaporkan post ini..."
            className="w-full border rounded px-2 py-1 text-sm"
          />
          <button onClick={submitReport} className="mt-1 text-red-600 text-xs font-medium">
            Kirim Laporan
          </button>
        </div>
      )}

      <div className="mt-3 flex items-center gap-1 text-sm text-gray-500 border-t pt-2">
        <button
          onClick={() => react("LIKE")}
          className={`flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg hover:bg-gray-50 ${
            state.myReaction === "LIKE" ? "text-emerald-600 font-semibold" : ""
          }`}
        >
          👍 {state.likeCount}
        </button>
        <button
          onClick={() => react("DISLIKE")}
          className={`flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg hover:bg-gray-50 ${
            state.myReaction === "DISLIKE" ? "text-red-500 font-semibold" : ""
          }`}
        >
          👎 {state.dislikeCount}
        </button>
        <Link
          href={`/post/${state.id}`}
          className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg hover:bg-gray-50"
        >
          💬 {state.commentCount}
        </Link>
        <button onClick={share} className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg hover:bg-gray-50">
          🔁 {state.shareCount}
        </button>
        <button onClick={toggleBookmark} className="flex-1 flex items-center justify-center py-1.5 rounded-lg hover:bg-gray-50">
          {state.isBookmarked ? "🔖" : "📑"}
        </button>
      </div>
    </div>
  );
}
