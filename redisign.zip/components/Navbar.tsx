"use client";

import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { useState } from "react";

export default function Navbar() {
  const { data: session, status } = useSession();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-gray-200">
      <div className="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between">
        <Link href="/" className="font-bold text-lg text-emerald-700">
          📚 BookClub
        </Link>

        <nav className="flex items-center gap-3 text-sm">
          {status === "loading" ? null : session ? (
            <>
              <Link href="/create" className="hidden sm:inline-block px-3 py-1.5 bg-emerald-600 text-white rounded-full hover:bg-emerald-700">
                + Post
              </Link>
              <Link href="/notifications" className="text-gray-600 hover:text-emerald-700" title="Notifikasi">
                🔔
              </Link>
              <Link href="/messages" className="text-gray-600 hover:text-emerald-700" title="Pesan CS">
                💬
              </Link>
              <Link href="/reading-list" className="text-gray-600 hover:text-emerald-700" title="Reading List">
                📖
              </Link>
              {(session.user.role === "ADMIN" || session.user.role === "PEMBINA") && (
                <Link href="/admin" className="text-gray-600 hover:text-emerald-700" title="Dashboard Admin">
                  🛠️
                </Link>
              )}

              <div className="relative">
                <button onClick={() => setOpen((o) => !o)} className="flex items-center gap-1">
                  <img
                    src={session.user.avatarUrl || `https://api.dicebear.com/7.x/initials/svg?seed=${session.user.name}`}
                    alt="avatar"
                    className="w-8 h-8 rounded-full object-cover border"
                  />
                </button>
                {open && (
                  <div className="absolute right-0 mt-2 w-44 bg-white border rounded-lg shadow-lg py-1">
                    <Link href={`/profile/${session.user.username}`} className="block px-4 py-2 hover:bg-gray-50" onClick={() => setOpen(false)}>
                      Profil Saya
                    </Link>
                    <Link href="/settings" className="block px-4 py-2 hover:bg-gray-50" onClick={() => setOpen(false)}>
                      Pengaturan
                    </Link>
                    <button
                      onClick={() => signOut({ callbackUrl: "/" })}
                      className="w-full text-left px-4 py-2 text-red-600 hover:bg-gray-50"
                    >
                      Keluar
                    </button>
                  </div>
                )}
              </div>
            </>
          ) : (
            <>
              <Link href="/login" className="px-3 py-1.5 text-emerald-700 hover:underline">
                Masuk
              </Link>
              <Link href="/register" className="px-3 py-1.5 bg-emerald-600 text-white rounded-full hover:bg-emerald-700">
                Daftar
              </Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
