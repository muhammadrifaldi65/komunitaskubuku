"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession } from "next-auth/react";

const NAV = [
  { href: "/admin", label: "Ringkasan", icon: "📊" },
  { href: "/admin/users", label: "Pengguna", icon: "👥" },
  { href: "/admin/posts", label: "Konten", icon: "📝" },
  { href: "/admin/reports", label: "Laporan", icon: "🚩" },
  { href: "/admin/chat", label: "Customer Service", icon: "💬" },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { data: session } = useSession();

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 flex gap-6">
      <aside className="w-48 shrink-0 hidden sm:block">
        <div className="bg-white border rounded-xl p-2 sticky top-20">
          <p className="text-xs text-gray-400 px-2 py-1">
            Login sebagai {session?.user.role === "ADMIN" ? "Admin" : "Pembina"}
          </p>
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm mb-0.5 ${
                pathname === item.href ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-700"
              }`}
            >
              <span>{item.icon}</span> {item.label}
            </Link>
          ))}
        </div>
      </aside>
      <div className="flex-1 min-w-0">{children}</div>
    </div>
  );
}
